#include <stdio.h>

int main(){
 printf("good bye...\n");
 return 0;
}

