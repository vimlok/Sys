#include<stdio.h>

int main(int argc, char* argv[]){
 int y ;
 printf("y is %d \n", 12);
 return 0;
}
