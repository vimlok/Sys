#include <stdio.h>

int gcd(int a, int b);

int main(void) {

	int test1 = 8; int test2 = 12;
	int gcd_test1 = gcd(test1, test2);
	printf("GCD of %d and %d is : %d\n", test1, test2, gcd_test1);

	int test3 = 2; int test4 = 5;
	int gcd_test2 = gcd(test3, test4);
	printf("GCD of %d and %d is : %d\n", test3, test4, gcd_test2);

	int test5 = 124; int test6 = 42152;
	int gcd_test3 = gcd(test5, test6);
	printf("GCD of %d and %d is : %d\n", test5, test6, gcd_test3);	
}

int gcd(int a, int b) {
/**
 * Function takes first integer a and finds it's greatest common divisor with integer b
 * If there are no GCD then it simply returns 1 since it still counts as a GCD
 *
 * in int a: integer used in conjunction with int b in order to find GCD
 * in int b: integer used in conjunction with int a in roder to find GCD
 * out int gcd_number: integer used to keep track of the largest GCD, it updates if one is found through a for loop
 *
 * Return: returns gcd_number, if no gcd was found, it will still return 1 which is considered a GCD*/
	int gcd_number = 1;

	for (int i = 1; i <= a && i <= b; i++) {
		if (a % i == 0 && b % i == 0) {
			gcd_number = i;
		}
	}

	return gcd_number;
}
